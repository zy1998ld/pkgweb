#' Generate pic by GFN
#'
#' @param data_list a list of data
#' @param traits a vector of outcome
#' @param formula_list a list of formula of model
#' @param XYZ_list a list of x y z axis
#' @param predict_val prediction data of variables
#' @param exclude
#' @param csv.file file path
#' @param pdf.file pdf path
#' @param slice_at data slice
#' @param fit.resolution the length of variable in predction
#' @param no.cols the length of color
#' @param nlev
#' @param include_se logical value
#' @param markers
#' @param scale_surface numeric
#' @param cex.axis pic option
#' @param labels_list a list of labels for x y z
#' @param cex.lab pic option
#' @param direction pic option
#' @param method.fit fit method
#' @import dplyr
#' @import gam
#' @import ggplot2
#'
#' @return a model result (if) a pic (if)
#' @export
#'
my.gam<-function(data_list, traits, formula_list, XYZ_list=NA, predict_val=NA, exclude=NULL, csv.file=NA, pdf.file=NA, slice_at=NA, fit.resolution=101, no.cols=256, nlev=8, include_se=F, markers=NA, scale_surface=NA, cex.axis=2, labels_list=XYZ_list, cex.lab=2, direction=1, method.fit="GCV.Cp"){

  # If we want to plot the surfaces
  if(is.na(pdf.file) == F){
    # Set the layout
    # Open the pdf file for plotting
    if(include_se == T){
      # DO you want surfaces for SE
      if(direction == 1){
        # Set the layout for direction 1 - reading left to right: lower, middle, upper slice
        pdf(pdf.file, height=6 * 5, width=3 * 5)
        par(mfrow=c(6, 3), mar=c(6,6,5,1))
      }else{
        # Set the layout for direction 2 - reading top to bottom: lower, middle, upper slice
        pdf(pdf.file, height=3 * 5, width=6 * 5)
        par(mar=c(6,6,5,1))
        layout(as.matrix(array(seq(1, 6*3, 1), c(3, 6))))
      }
    }else{
      pdf(pdf.file, height=3 * 5, width=3 * 5)
      if(direction == 1){
        par(mfrow=c(3, 3), mar=c(6,6,5,1))
      }else{
        par(mar=c(6,6,5,1))
        layout(as.matrix(array(seq(1, 3*3, 1), c(3, 3))))
      }
    }
  }

  # Order the markers
  markers_list<-list()
  if(is.list(markers) == T){
    markers_list[[1]]<-list(markers[[1]], markers[[2]])
    markers_list[[2]]<-list(markers[[1]], markers[[3]])
    markers_list[[3]]<-list(markers[[2]], markers[[3]])
  }

  # This specifies the color scheme for surface
  rgb.palette<-colorRampPalette(c("blue","cyan","yellow","red"), space="Lab", interpolate="linear")
  map<-rgb.palette(no.cols)

  # create the csv file to write to, if you want one
  if(is.na(csv.file) == F){
    write.table(Sys.time(), file=csv.file, sep=",", row.names=F, col.names=F)
    write.table(" ", file=csv.file, sep=",", row.names=F, col.names=F, append=T)
  }

  # List to hold the fitted models
  models.list<-list()

  # Formatting the progress bar
  pb <- txtProgressBar(min = 0, max = length(traits), style = 3)
  progress<-0

  # Loop for the proteins
  for(k in 1:length(traits)){

    # Pull out the kth dataset
    data<-data_list[[k]]

    # write the trait to the table
    if(is.na(csv.file) == F){
      write.table(traits[k], file=csv.file, sep=",", row.names=F, col.names=F, append=T)
    }

    # Get the kth trait as the outcome
    data$outcome<-data[,traits[k]]

    # Format the formula
    formula_fit<-as.formula(paste0("outcome ", formula_list[[k]]))

    # Fit the model
    GAM<-gam(formula_fit, data=data, method=method.fit)

    # Save the GAM
    models.list[[k]]<-GAM
    names(models.list)[k]<-traits[k]
    ..0
    # Writing output
    if(is.na(csv.file) == F){
      # Write the linear terms
      p.table<-round(summary(GAM)$p.table, 4)
      p.table<-as.data.frame(cbind(row.names(p.table), p.table))
      names(p.table)[1]<-"Coef."
      suppressWarnings(write.table(p.table, file=csv.file, sep=",", row.names=F, col.names=names(p.table), append=T))
      write.table(" ", file=csv.file, sep=",", row.names=F, col.names=F, append=T)

      # Write the smooth terms
      s.table<-round(summary(GAM)$s.table, 4)
      s.table<-as.data.frame(cbind(row.names(s.table), s.table))
      names(s.table)[1]<-"Coef."
      suppressWarnings(write.table(s.table, file=csv.file, sep=",", row.names=F, col.names=names(s.table), append=T))
      write.table(" ", file=csv.file, sep=",", row.names=F, col.names=F, append=T)

      # Write the n and deviance explained
      dev.expl<-paste0("n = ", summary(GAM)$n, ": % Dev. Explained = ", round(summary(GAM)$dev.expl * 100, 2), ": AIC = ", round(AIC(GAM)))
      write.table(dev.expl, file=csv.file, sep=",", row.names=F, col.names=F, append=T)
      write.table(" ", file=csv.file, sep=",", row.names=F, col.names=F, append=T)
    }

    # If we are plotting the surface make the surfaces
    if(is.na(pdf.file) == F){

      # List for the order of plots
      list.order<-list()
      list.order[[1]]<-XYZ_list[[k]][c(1,2,3)]
      list.order[[2]]<-XYZ_list[[k]][c(1,3,2)]
      list.order[[3]]<-XYZ_list[[k]][c(2,3,1)]

      # List for the labels
      labels.order<-list()
      labels.order[[1]]<-labels_list[[k]][c(1,2,3)]
      labels.order[[2]]<-labels_list[[k]][c(1,3,2)]
      labels.order[[3]]<-labels_list[[k]][c(2,3,1)]

      # Lists to hold the predictions for the nth combinations
      predictors.list<-list()
      predictions.list<-list()
      xyz.list<-list()
      cv.list<-list()

      # Go through the nutrient orders and get the predicted values, note we will do the predictions for all three combinations, then find the minimla and maximal values, then go back though the nutrients orders and plot out
      for(n in 1:3){

        # Order to plot the nutrients
        nutrient.order<-list.order[[n]]

        # Values to predict over
        x.limits<-c(floor(min(data[,nutrient.order[1]])), ceiling(max(data[,nutrient.order[1]])))
        y.limits<-c(floor(min(data[,nutrient.order[2]])), ceiling(max(data[,nutrient.order[2]])))

        # If we do not specify values to slice at, use the 25, 50, and 75 %ile
        if(is.list(slice_at) == F){
          z.vals<-round(quantile(data[,nutrient.order[3]])[c(2:4)])
        }else{
          z.vals<-slice_at[[k]]
        }

        # Fitted list to hold some results for later
        x.new<-seq(min(x.limits, na.rm=T), max(x.limits, na.rm=T), len=fit.resolution)
        y.new<-seq(min(y.limits, na.rm=T), max(y.limits, na.rm=T), len=fit.resolution)
        z.new<-z.vals
        predictors<-as.data.frame(expand.grid(x.new, y.new, z.new))
        names(predictors)<-nutrient.order
        in.poly<-as.numeric(inhull(predictors[,c(1:3)], data[,names(predictors)]) != -1)

        # Add the predictors for the additional 'confounders'
        predictors<-cbind(predictors, predict_val)

        # Do the predictions
        predictions<-predict(GAM, newdata=predictors, type="response", exclude=exclude, se.fit=T)

        # Edit out based on the marker list
        predictions$fit[which(in.poly == 0)]<-NA
        predictions$se.fit[which(in.poly == 0)]<-NA

        # Save the nth set of predictions
        predictions.list[[n]]<-predictions$fit
        predictors.list[[n]]<-predictors
        xyz.list[[n]]<-list(x.new, y.new, z.new)
        cv.list[[n]]<-predictions$se.fit
      }

      # Find the min and max values across all predictions
      mn<-min(unlist(predictions.list), na.rm=T)
      mx<-max(unlist(predictions.list), na.rm=T)

      # If no color scale is specified for the outcomes scale by the predicted values
      if(sum(is.na(scale_surface)) < length(scale_surface)){
        # Find the absolute max values across all predictions, and the scale
        upp_abs<-max(abs(c(scale_surface, mn, mx)))
        mn<-(-upp_abs)
        mx<-upp_abs
      }

      # now do the coefficient of the error
      mn.cv<-min(unlist(cv.list), na.rm=T)
      mx.cv<-max(unlist(cv.list), na.rm=T)

      # Now go back though the predictions and plot
      for(n in 1:3){

        # Order to plot the nutrients
        nutrient.order<-list.order[[n]]
        labs<-labels.order[[n]]

        # Pull out the nth set of predictors and predictions
        predictors<-predictors.list[[n]]
        predictions<-predictions.list[[n]]
        x.new<-xyz.list[[n]][[1]]
        y.new<-xyz.list[[n]][[2]]
        z.new<-xyz.list[[n]][[3]]

        # Do the 3 quantiles for the predictions
        for(i in 1:length(z.new)){

          # Subset for the ith quantile
          ith_Quantile<-predictions[which(predictors[, nutrient.order[3]] == z.new[i])]

          surf<-matrix(ith_Quantile, nrow=fit.resolution)

          locs<-round((range(surf, na.rm=TRUE) - mn) / (mx-mn) * no.cols)
          image(x.new, y.new, surf, col=map[locs[1]:locs[2]], xlab="", ylab="", axes=FALSE)
          mtext(paste0(labs[3], " = ", z.new[i]), line=1, cex=cex.lab)
          mtext(labs[1], side=1, line=4, cex=cex.lab)
          mtext(labs[2], side=2, line=4, cex=cex.lab)
          if(i == 3 & n == 1){
            mtext(traits[k], line=2, font=1, cex=1, at = max(x.new)*0.9)
          }
          axis(1, cex.axis=cex.axis)
          axis(2, cex.axis=cex.axis)
          contour(x.new, y.new, surf, add=TRUE, levels=pretty(range(mn, mx), nlev), labcex=1, lwd=3)
          # Add any markers
          if(is.list(markers) == T){
            abline(v=markers_list[[n]][[1]], col="grey")
            abline(h=markers_list[[n]][[2]], col="grey")
          }

        }

        # Now the 3 quantiles for the errors if we want those
        if(include_se == T){

          # Pull out the nth set of errors
          predictions<-cv.list[[n]]

          # GO through each quantile
          for(i in 1:length(z.new)){

            # Subset for the ith quantile
            ith_Quantile<-predictions[which(predictors[, nutrient.order[3]] == z.new[i])]

            surf<-matrix(ith_Quantile, nrow=fit.resolution)

            locs<-round((range(surf, na.rm=TRUE) - mn.cv) / (mx.cv-mn.cv) * no.cols)
            image(x.new, y.new, surf, col=map[locs[1]:locs[2]], xlab="", ylab="", axes=FALSE)
            mtext(paste0("se"), line=1, cex=cex.lab)
            mtext(labs[1], side=1, line=4, cex=cex.lab)
            mtext(labs[2], side=2, line=4, cex=cex.lab)
            axis(1, cex.axis=cex.axis)
            axis(2, cex.axis=cex.axis)
            contour(x.new, y.new, surf, add=TRUE, levels=pretty(range(mn.cv, mx.cv), nlev), labcex=1, lwd=3)

          }
        }
      }
    }

    # Update the progress
    progress<-progress + 1
    setTxtProgressBar(pb, progress)
  }

  if(is.na(pdf.file) == F){
    # Close the file
    dev.off()
  }

  # Return the models listed
  return(models.list)

}
